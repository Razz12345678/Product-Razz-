CARA PAKAI
1. Buka index.html untuk tes.
2. Edit bagian CONFIG di bawah file index.html:
   - product
   - role
   - duration
   - price
   - minimumDpPercent
   - telegramUsername
   - whatsappNumber
3. Jangan ubah nama qris.png kecuali src gambarnya juga diubah.
4. Upload index.html + qris.png ke Vercel/Netlify/GitHub Pages.

QRIS pada folder ini diambil dari foto QRIS yang kamu kirim.
